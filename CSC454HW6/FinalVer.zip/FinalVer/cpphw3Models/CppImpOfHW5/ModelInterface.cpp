/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ModelInterface.cpp
 * Author: chrisrk192
 * 
 * Created on September 29, 2017, 2:21 PM
 */

#include "ModelInterface.h"

ModelInterface::ModelInterface() {
}

ModelInterface::ModelInterface(const ModelInterface& orig) {
}

ModelInterface::~ModelInterface() {
}

 std::string ModelInterface::GetInitilizationSignature(){
 
}

 void ModelInterface::Initialize(std::vector<std::string> v){
    
}

 std::vector<std::string> ModelInterface::OutPut(){

}  

 void ModelInterface::StateTransition(std::vector<std::string> v){

}

 std::string ModelInterface::GetStatus(){
    return "poop";
}  
std::vector<std::string> ModelInterface::Tick(std::vector<std::string>){

}


